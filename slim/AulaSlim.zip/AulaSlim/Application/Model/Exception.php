<?php

class Application_Model_Exception extends Exception {
    
}
