<?php

class Application_Model_DbTable_Categoria extends Zend_Db_Table_Abstract
{
    protected $_name = 'categoria';
    protected $_primary = 'idcategoria';
}

