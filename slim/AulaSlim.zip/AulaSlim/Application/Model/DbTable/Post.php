<?php

class Application_Model_DbTable_Post extends Zend_Db_Table_Abstract
{
    protected $_name = 'post';
    protected $_primary = 'idpost';
}

