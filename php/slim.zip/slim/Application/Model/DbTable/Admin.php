<?php

class Application_Model_DbTable_Admin extends Zend_Db_Table_Abstract
{
    protected $_name = 'admin';
    protected $_primary = 'idadmin';
}

