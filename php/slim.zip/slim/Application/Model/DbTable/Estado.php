<?php

class Application_Model_DbTable_Estado extends Zend_Db_Table_Abstract
{
    protected $_name = 'estado';
    protected $_primary = 'idestado';
}

